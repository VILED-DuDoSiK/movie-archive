const OMDb_API_KEY = 'b9a5e69d';
const OMDb_BASE_URL = 'https://www.omdbapi.com';
const CACHE_KEY = 'movieArchiveCache';
const CACHE_EXPIRY = 24 * 60 * 60 * 1000; // 24 часа

let currentPage = 1;
let currentCategory = 'popular';
let searchQuery = '';
let isLoading = false;
let allMovies = [];
let filteredMovies = [];
let itemsPerPage = 24;
let currentDisplayPage = 1;
let allGenres = [
  'Action', 'Adventure', 'Animation', 'Biography', 'Comedy', 'Crime', 'Documentary',
  'Drama', 'Family', 'Fantasy', 'Film-Noir', 'Game-Show', 'History', 'Horror',
  'Music', 'Musical', 'Mystery', 'News', 'Reality-TV', 'Romance', 'Sci-Fi',
  'Sport', 'Talk-Show', 'Thriller', 'War', 'Western'
];
let currentGenreIndex = 0;

const moviesGrid = document.getElementById('moviesGrid');
const searchInput = document.getElementById('searchInput');
const btnPopular = document.getElementById('btnPopular');
const btnTop = document.getElementById('btnTop');
const btnFavorites = document.getElementById('btnFavorites');
const btnResetFilters = document.getElementById('btnResetFilters');
const btnLoadMore = document.getElementById('btnLoadMore');
const loadMoreContainer = document.getElementById('loadMoreContainer');
const resultsInfo = document.getElementById('resultsInfo');
const pagination = document.getElementById('pagination');
const itemsPerPageSelect = document.getElementById('itemsPerPage');

const filterGenre = document.getElementById('filterGenre');
const filterCountry = document.getElementById('filterCountry');
const filterYearFrom = document.getElementById('filterYearFrom');
const filterYearTo = document.getElementById('filterYearTo');
const filterType = document.getElementById('filterType');
const filterRatingFrom = document.getElementById('filterRatingFrom');
const filterRatingTo = document.getElementById('filterRatingTo');
const filterSort = document.getElementById('filterSort');

function getCache() {
  try {
    const cached = localStorage.getItem(CACHE_KEY);
    if (cached) {
      const { data, timestamp } = JSON.parse(cached);
      const isExpired = Date.now() - timestamp > CACHE_EXPIRY;
      if (!isExpired && data.length > 0) {
        console.log('Using cached data:', data.length, 'movies');
        return data;
      }
    }
  } catch (e) {
    console.error('Cache error:', e);
  }
  return null;
}

function setCache(data) {
  try {
    const cache = { data, timestamp: Date.now() };
    localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
    console.log('Cached', data.length, 'movies');
  } catch (e) {
    console.error('Cache save error:', e);
  }
}

function clearCache() {
  localStorage.removeItem(CACHE_KEY);
}

async function fetchWithTimeout(url, timeout = 15000) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  
  try {
    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(id);
    return response;
  } catch (error) {
    clearTimeout(id);
    throw error;
  }
}

async function fetchMoviesBatch(keywords, batchSize = 10) {
  const movies = [];
  const batches = [];
  
  for (let i = 0; i < keywords.length; i += batchSize) {
    batches.push(keywords.slice(i, i + batchSize));
  }
  
  for (const batch of batches) {
    const results = await Promise.allSettled(
      batch.map(async (keyword) => {
        try {
          const url = `${OMDb_BASE_URL}/?s=${encodeURIComponent(keyword)}&apikey=${OMDb_API_KEY}`;
          const response = await fetchWithTimeout(url);
          const data = await response.json();
          return data.Search || [];
        } catch (e) {
          console.error(`Error fetching ${keyword}:`, e);
          return [];
        }
      })
    );
    
    results.forEach(result => {
      if (result.status === 'fulfilled' && result.value) {
        movies.push(...result.value);
      }
    });
  }
  
  return [...new Map(movies.map(m => [m.imdbID, m])).values()];
}

async function fetchMovieDetailsBatch(imdbIDs, batchSize = 20) {
  const batches = [];
  
  for (let i = 0; i < imdbIDs.length; i += batchSize) {
    batches.push(imdbIDs.slice(i, i + batchSize));
  }
  
  const allDetails = [];
  
  for (const batch of batches) {
    const results = await Promise.allSettled(
      batch.map(async (imdbID) => {
        try {
          const url = `${OMDb_BASE_URL}/?i=${imdbID}&apikey=${OMDb_API_KEY}`;
          const response = await fetchWithTimeout(url);
          return await response.json();
        } catch (e) {
          return null;
        }
      })
    );
    
    results.forEach(result => {
      if (result.status === 'fulfilled' && result.value && result.value.imdbID) {
        allDetails.push(result.value);
      }
    });
  }
  
  return allDetails;
}

async function fetchMoviesByGenre(genre) {
  const commonWords = ['movie', 'film', 'story', 'tale', 'chronicle', 'saga', 'adventure'];
  const movieResults = [];
  
  for (const word of commonWords) {
    try {
      const url = `${OMDb_BASE_URL}/?s=${encodeURIComponent(word)}&type=movie&apikey=${OMDb_API_KEY}`;
      const response = await fetchWithTimeout(url);
      const data = await response.json();
      
      if (data && data.Search && Array.isArray(data.Search)) {
        movieResults.push(...data.Search);
      }
    } catch (e) {
      console.error(`Error fetching ${genre} with ${word}:`, e);
    }
  }
  
  const uniqueMovies = [...new Map(movieResults.map(m => [m.imdbID, m])).values()];
  const details = await fetchMovieDetailsBatch(uniqueMovies.slice(0, 30).map(m => m.imdbID));
  
  const filteredByGenre = details.filter(movie => 
    movie && movie.Genre && movie.Genre.toLowerCase().includes(genre.toLowerCase())
  );
  
  return filteredByGenre;
}

async function fetchPopularMovies() {
  currentGenreIndex = 0;
  
  const cached = getCache();
  if (cached && cached.length > 0) {
    return cached;
  }
  
  const popularGenres = ['Action', 'Drama', 'Comedy', 'Thriller', 'Horror', 'Adventure', 'Sci-Fi', 'Romance'];
  
  const allMovieData = [];
  
  for (const genre of popularGenres) {
    const genreMovies = await fetchMoviesByGenre(genre);
    allMovieData.push(...genreMovies);
    
    updateLoadingProgress(genre, popularGenres.indexOf(genre), popularGenres.length);
  }
  
  const uniqueMovies = [...new Map(allMovieData.map(m => [m.imdbID, m])).values()];
  setCache(uniqueMovies);
  
  return uniqueMovies;
}

function updateLoadingProgress(genre, current, total) {
  if (searchQuery || currentCategory === 'favorites') return;
  const percentage = Math.round((current / total) * 100);
  resultsInfo.textContent = `Загрузка ${genre}... ${percentage}%`;
}

async function fetchTopMovies() {
  const topKeywords = [
    'godfather', 'shawshank', 'inception', 'matrix', 'pulp', 'fight', 'forrest',
    'dark', 'interstellar', 'parasite', 'breaking', 'wire', 'sopranos',
    'twin', 'goodfellas', 'pianist', 'schindler', 'casablanca', 'citizen',
    'vertigo', 'psycho', 'rear', 'north', '2001'
  ];
  
  const searchResults = await fetchMoviesBatch(topKeywords, 15);
  const details = await fetchMovieDetailsBatch(searchResults.map(m => m.imdbID), 30);
  
  return details.filter(m => m !== null && m.imdbID);
}

async function loadMoreMovies() {
  if (isLoading || currentGenreIndex >= allGenres.length) return;
  
  btnLoadMore.disabled = true;
  btnLoadMore.textContent = 'Загрузка...';
  isLoading = true;

  try {
    const nextGenres = allGenres.slice(currentGenreIndex, currentGenreIndex + 4);
    
    const genreMovies = await Promise.all(
      nextGenres.map(genre => fetchMoviesByGenre(genre))
    );
    
    const flatMovies = genreMovies.flat();
    currentGenreIndex += 4;
    
    if (flatMovies.length > 0) {
      const newIds = new Set(allMovies.map(m => m.imdbID));
      const uniqueNewMovies = flatMovies.filter(m => m && !newIds.has(m.imdbID));
      
      allMovies = [...allMovies, ...uniqueNewMovies];
      setCache(allMovies);
      populateFilters(allMovies);
      applyFilters();
    }
    
    if (currentGenreIndex >= allGenres.length) {
      btnLoadMore.textContent = 'Все жанры загружены';
      btnLoadMore.disabled = true;
    } else {
      btnLoadMore.textContent = `Загрузить ещё (жанры: ${currentGenreIndex}/${allGenres.length})`;
      btnLoadMore.disabled = false;
    }
  } catch (error) {
    console.error('Error loading more movies:', error);
    btnLoadMore.textContent = 'Ошибка загрузки';
    btnLoadMore.disabled = false;
  }
  
  isLoading = false;
}

async function searchMovies(query, page = 1) {
  const url = `${OMDb_BASE_URL}/?s=${encodeURIComponent(query)}&apikey=${OMDb_API_KEY}`;
  
  const response = await fetchWithTimeout(url);
  const data = await response.json();
  
  if (data.Response === 'False' || !data.Search) return { Search: [] };
  
  const moviesWithDetails = await fetchMovieDetailsBatch(
    data.Search.map(m => m.imdbID), 
    25
  );
  
  return { Search: moviesWithDetails.filter(m => m !== null) };
}

function getFavorites() {
  const favorites = localStorage.getItem('movieFavorites');
  return favorites ? JSON.parse(favorites) : [];
}

function saveFavorite(movie) {
  const favorites = getFavorites();
  const index = favorites.findIndex(m => m.imdbID === movie.imdbID);
  
  if (index > -1) {
    favorites.splice(index, 1);
  } else {
    favorites.push(movie);
  }
  
  localStorage.setItem('movieFavorites', JSON.stringify(favorites));
  return index === -1;
}

function isFavorite(imdbID) {
  return getFavorites().some(m => m.imdbID === imdbID);
}

function openInRutube(title) {
  const searchUrl = `https://rutube.ru/search/?query=${encodeURIComponent(title)}`;
  window.open(searchUrl, '_blank');
}

function extractGenres(movies) {
  const genreSet = new Set();
  movies.forEach(movie => {
    if (movie.Genre) {
      movie.Genre.split(',').forEach(g => genreSet.add(g.trim()));
    }
  });
  return Array.from(genreSet).sort();
}

function extractCountries(movies) {
  const countrySet = new Set();
  movies.forEach(movie => {
    if (movie.Country) {
      movie.Country.split(',').forEach(c => countrySet.add(c.trim()));
    }
  });
  return Array.from(countrySet).sort();
}

function extractYears(movies) {
  const yearSet = new Set();
  movies.forEach(movie => {
    if (movie.Year) {
      const year = parseInt(movie.Year);
      if (!isNaN(year)) {
        yearSet.add(year);
      }
    }
  });
  return Array.from(yearSet).sort((a, b) => b - a);
}

function populateFilters(movies) {
  const genres = extractGenres(movies);
  const countries = extractCountries(movies);
  const years = extractYears(movies);

  const currentGenre = filterGenre.value;
  const currentCountry = filterCountry.value;
  const currentYearFrom = filterYearFrom.value;
  const currentYearTo = filterYearTo.value;

  filterGenre.innerHTML = '<option value="">Все жанры</option>';
  genres.forEach(genre => {
    const option = document.createElement('option');
    option.value = genre;
    option.textContent = genre;
    if (genre === currentGenre) option.selected = true;
    filterGenre.appendChild(option);
  });

  filterCountry.innerHTML = '<option value="">Все страны</option>';
  countries.forEach(country => {
    const option = document.createElement('option');
    option.value = country;
    option.textContent = country;
    if (country === currentCountry) option.selected = true;
    filterCountry.appendChild(option);
  });

  filterYearFrom.innerHTML = '<option value="">От</option>';
  filterYearTo.innerHTML = '<option value="">До</option>';
  years.forEach(year => {
    const optFrom = document.createElement('option');
    optFrom.value = year;
    optFrom.textContent = year;
    if (year.toString() === currentYearFrom) optFrom.selected = true;
    filterYearFrom.appendChild(optFrom);

    const optTo = document.createElement('option');
    optTo.value = year;
    optTo.textContent = year;
    if (year.toString() === currentYearTo) optTo.selected = true;
    filterYearTo.appendChild(optTo);
  });
}

function applyFilters() {
  filteredMovies = [...allMovies];

  if (filterGenre.value) {
    filteredMovies = filteredMovies.filter(m => 
      m.Genre && m.Genre.includes(filterGenre.value)
    );
  }

  if (filterCountry.value) {
    filteredMovies = filteredMovies.filter(m => 
      m.Country && m.Country.includes(filterCountry.value)
    );
  }

  if (filterYearFrom.value) {
    filteredMovies = filteredMovies.filter(m => 
      m.Year && parseInt(m.Year) >= parseInt(filterYearFrom.value)
    );
  }

  if (filterYearTo.value) {
    filteredMovies = filteredMovies.filter(m => 
      m.Year && parseInt(m.Year) <= parseInt(filterYearTo.value)
    );
  }

  if (filterType.value) {
    filteredMovies = filteredMovies.filter(m => 
      m.Type === filterType.value
    );
  }

  if (filterRatingFrom.value) {
    filteredMovies = filteredMovies.filter(m => 
      m.imdbRating && parseFloat(m.imdbRating) >= parseFloat(filterRatingFrom.value)
    );
  }

  if (filterRatingTo.value) {
    filteredMovies = filteredMovies.filter(m => 
      m.imdbRating && parseFloat(m.imdbRating) <= parseFloat(filterRatingTo.value)
    );
  }

  const sortValue = filterSort.value;
  if (sortValue === 'year-desc') {
    filteredMovies.sort((a, b) => parseInt(b.Year) - parseInt(a.Year));
  } else if (sortValue === 'year-asc') {
    filteredMovies.sort((a, b) => parseInt(a.Year) - parseInt(b.Year));
  } else if (sortValue === 'rating-desc') {
    filteredMovies.sort((a, b) => parseFloat(b.imdbRating || 0) - parseFloat(a.imdbRating || 0));
  } else if (sortValue === 'rating-asc') {
    filteredMovies.sort((a, b) => parseFloat(a.imdbRating || 0) - parseFloat(b.imdbRating || 0));
  } else if (sortValue === 'title-asc') {
    filteredMovies.sort((a, b) => a.Title.localeCompare(b.Title, 'ru'));
  } else if (sortValue === 'title-desc') {
    filteredMovies.sort((a, b) => b.Title.localeCompare(a.Title, 'ru'));
  }

  currentDisplayPage = 1;
  renderMovies();
  renderPagination();
  updateResultsInfo(filteredMovies.length);
}

function updateResultsInfo(count) {
  if (currentCategory === 'favorites') {
    resultsInfo.textContent = `Избранные фильмы: ${count}`;
  } else if (searchQuery) {
    resultsInfo.textContent = `Результаты поиска: ${count}`;
  } else {
    resultsInfo.textContent = `Найдено фильмов: ${count}`;
  }
}

function renderMovies() {
  const start = (currentDisplayPage - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  const moviesToRender = filteredMovies.slice(start, end);
  
  moviesGrid.innerHTML = '';
  
  if (!moviesToRender || moviesToRender.length === 0) {
    moviesGrid.innerHTML = '<div class="error">Фильмы не найдены</div>';
    pagination.innerHTML = '';
    return;
  }
  
  moviesToRender.forEach((movie, index) => {
    const card = createMovieCard(movie);
    card.style.animationDelay = `${index * 0.05}s`;
    moviesGrid.appendChild(card);
  });
}

function renderPagination() {
  const totalPages = Math.ceil(filteredMovies.length / itemsPerPage);
  
  if (totalPages <= 1) {
    pagination.innerHTML = '';
    return;
  }

  let html = '';
  
  html += `<button ${currentDisplayPage === 1 ? 'disabled' : ''} onclick="changePage(1)">«</button>`;
  html += `<button ${currentDisplayPage === 1 ? 'disabled' : ''} onclick="changePage(${currentDisplayPage - 1})">‹</button>`;

  const startPage = Math.max(1, currentDisplayPage - 2);
  const endPage = Math.min(totalPages, currentDisplayPage + 2);

  for (let i = startPage; i <= endPage; i++) {
    html += `<button class="${i === currentDisplayPage ? 'active' : ''}" onclick="changePage(${i})">${i}</button>`;
  }

  html += `<button ${currentDisplayPage === totalPages ? 'disabled' : ''} onclick="changePage(${currentDisplayPage + 1})">›</button>`;
  html += `<button ${currentDisplayPage === totalPages ? 'disabled' : ''} onclick="changePage(${totalPages})">»</button>`;

  pagination.innerHTML = html;
}

window.changePage = function(page) {
  currentDisplayPage = page;
  renderMovies();
  renderPagination();
  window.scrollTo({ top: 0, behavior: 'smooth' });
};

function createMovieCard(movie) {
  const card = document.createElement('div');
  card.className = 'movie-card';
  
  const posterPath = movie.Poster && movie.Poster !== 'N/A' 
    ? movie.Poster 
    : 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="400" height="600"%3E%3Crect fill="%231a1a1a" width="400" height="600"/%3E%3Ctext fill="%238a857d" x="50%25" y="50%25" text-anchor="middle" dy=".3em" font-family="Courier Prime, monospace"%3ENo Image%3C/text%3E%3C/svg%3E';
  
  const rating = movie.imdbRating && movie.imdbRating !== 'N/A' ? movie.imdbRating : '—';
  const year = movie.Year && movie.Year !== 'N/A' ? movie.Year : '—';
  const genre = movie.Genre ? movie.Genre.split(',').slice(0, 2).join(' / ') : (movie.Type === 'movie' ? 'Фильм' : movie.Type === 'series' ? 'Сериал' : movie.Type);
  const favActive = isFavorite(movie.imdbID) ? 'active' : '';

  card.innerHTML = `
    <img src="${posterPath}" alt="${movie.Title}" class="movie-poster" loading="lazy" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22600%22%3E%3Crect fill=%22%231a1a1a%22 width=%22400%22 height=%22600%22/%3E%3Ctext fill=%22%238a857d%22 x=%2250%25%22 y=%2250%25%22 text-anchor=%22middle%22 dy=%22.3em%22 font-family=%22Courier Prime, monospace%22%3ENo Image%3C/text%3E%3C/svg%3E'">
    <div class="movie-info">
      <h3 class="movie-title">${movie.Title}</h3>
      <div class="movie-meta">
        <span class="movie-year">${year}</span>
        <span class="movie-rating">
          <svg class="rating-icon" viewBox="0 0 24 24">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
          ${rating}
        </span>
      </div>
      <div class="movie-genres">${genre}</div>
      <div class="movie-actions">
        <button class="action-btn favorite ${favActive}" data-id="${movie.imdbID}">
          ${favActive ? '★ В избранном' : '☆ В избранное'}
        </button>
        <button class="action-btn watch-rutube" data-title="${movie.Title}">
          ▶ Смотреть
        </button>
      </div>
    </div>
  `;

  card.querySelector('.favorite').addEventListener('click', (e) => {
    e.stopPropagation();
    const btn = e.currentTarget;
    const added = saveFavorite(movie);
    btn.classList.toggle('active');
    btn.textContent = added ? '★ В избранном' : '☆ В избранное';
  });

  card.querySelector('.watch-rutube').addEventListener('click', (e) => {
    e.stopPropagation();
    openInRutube(movie.Title);
  });

  return card;
}

async function loadMovies() {
  if (isLoading) return;
  
  isLoading = true;
  moviesGrid.innerHTML = '<div class="loading">Загрузка</div>';
  pagination.innerHTML = '';
  loadMoreContainer.style.display = 'none';

  try {
    let movies;
    
    if (currentCategory === 'favorites') {
      movies = getFavorites() || [];
      if (movies.length === 0) {
        moviesGrid.innerHTML = '<div class="error">Нет избранных фильмов</div>';
        isLoading = false;
        return;
      }
    } else if (searchQuery) {
      const data = await searchMovies(searchQuery, currentPage);
      movies = data.Search || [];
    } else if (currentCategory === 'popular') {
      movies = await fetchPopularMovies();
    } else if (currentCategory === 'top') {
      movies = await fetchTopMovies();
    }

    allMovies = movies;
    populateFilters(allMovies);
    applyFilters();

    if (currentCategory !== 'favorites' && !searchQuery) {
      loadMoreContainer.style.display = 'block';
      btnLoadMore.textContent = `Загрузить ещё (жанры: ${currentGenreIndex}/${allGenres.length})`;
      btnLoadMore.disabled = false;
    }

  } catch (error) {
    console.error('Error:', error);
    moviesGrid.innerHTML = '<div class="error">Произошла ошибка: ' + error.message + '</div>';
  }
  
  isLoading = false;
}

function setActiveButton(activeBtn) {
  [btnPopular, btnTop, btnFavorites].forEach(btn => btn.classList.remove('active'));
  activeBtn.classList.add('active');
}

function resetFilters() {
  filterGenre.value = '';
  filterCountry.value = '';
  filterYearFrom.value = '';
  filterYearTo.value = '';
  filterType.value = '';
  filterRatingFrom.value = '';
  filterRatingTo.value = '';
  filterSort.value = 'default';
  applyFilters();
}

btnPopular.addEventListener('click', () => {
  currentCategory = 'popular';
  searchQuery = '';
  searchInput.value = '';
  currentPage = 1;
  currentGenreIndex = 0;
  setActiveButton(btnPopular);
  loadMovies();
});

btnTop.addEventListener('click', () => {
  currentCategory = 'top';
  searchQuery = '';
  searchInput.value = '';
  currentPage = 1;
  currentGenreIndex = 0;
  setActiveButton(btnTop);
  loadMovies();
});

btnFavorites.addEventListener('click', () => {
  currentCategory = 'favorites';
  searchQuery = '';
  searchInput.value = '';
  currentPage = 1;
  setActiveButton(btnFavorites);
  loadMovies();
});

btnResetFilters.addEventListener('click', resetFilters);
btnLoadMore.addEventListener('click', loadMoreMovies);

[filterGenre, filterCountry, filterYearFrom, filterYearTo, filterType, filterRatingFrom, filterRatingTo, filterSort].forEach(filter => {
  filter.addEventListener('change', applyFilters);
});

itemsPerPageSelect.addEventListener('change', (e) => {
  itemsPerPage = parseInt(e.target.value);
  currentDisplayPage = 1;
  renderMovies();
  renderPagination();
});

let searchTimeout;
searchInput.addEventListener('input', (e) => {
  clearTimeout(searchTimeout);
  searchQuery = e.target.value.trim();
  
  searchTimeout = setTimeout(() => {
    if (searchQuery.length > 2 || searchQuery.length === 0) {
      [btnPopular, btnTop, btnFavorites].forEach(btn => btn.classList.remove('active'));
      currentPage = 1;
      loadMovies();
    }
  }, 500);
});

loadMovies();
